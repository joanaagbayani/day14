import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Yellow from './Screens/Yellow';
import Red from './Screens/Red';
import Blue from './Screens/Blue';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Red">
        <Stack.Screen name="Red" component={Red} />
        <Stack.Screen name="Yellow" component={Yellow} />
        <Stack.Screen name="Blue" component={Blue} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
