import React from 'react';
import { View, Text, Button, StyleSheet, TouchableOpacity } from 'react-native';

const Yellow = ({ navigation }) => {
  return (
    <View style={[styles.container, { backgroundColor: '#FFFF00' }]}>
      <Text style={styles.text}>Yellow Screen</Text>
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#ff0000' }]} 
          onPress={() => navigation.navigate('Red')}
        >
          <Text style={styles.buttonText}>Go to Red</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#ffff66' }]} 
          onPress={() => navigation.navigate('Yellow')}
        >
          <Text style={styles.buttonText}>Go to Yellow</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#6666ff' }]} 
          onPress={() => navigation.navigate('Blue')}
        >
          <Text style={styles.buttonText}>Go to Blue</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  text: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 30,
  },
  buttonContainer: {
    width: '%',
    paddingHorizontal: 20,
    marginTop: 20,
    gap: 10,
  },
  button: {
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#000',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default Yellow;
